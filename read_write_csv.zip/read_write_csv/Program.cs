﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;

namespace read_write_csv
{
    class Program
    {
        class ReadWrite
        {
            public StreamReader streamr = new StreamReader("data.csv");
            public StreamWriter streamw = new StreamWriter("data.txt");
            
            public int count = 999999;
            public char[] buffer;
            public int i = 0;
            public async void read_1(object name)
            {
                while (i < count)
                {
                    if (i % 2 == 0)
                    {
                        buffer = new char[count];
                        try
                        {
                            await streamr.ReadAsync(buffer, i, count - 45);
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                            break;
                        }
                        streamw.WriteLine(buffer);
                        streamw.Flush();
                        buffer = null;
                        i++;
                    }  
                }
                Console.WriteLine(name);
            }
            public async void read_2(object name)
            {
                while (i < count)
                {
                    if (!(i % 2 == 0))
                    {
                        buffer = new char[count];
                        try
                        {
                            await streamr.ReadAsync(buffer, i, count - 45);
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                            break;
                        }
                        streamw.WriteLine(buffer);
                        streamw.Flush();
                        buffer = null;
                        i++;
                    }
                }
                Console.WriteLine(name);
            }
        }
    
        static void Main(string[] args)
        {    
            ReadWrite readwrite = new ReadWrite();
            Thread thread_1 = new Thread(new ParameterizedThreadStart(readwrite.read_1));
            Thread thread_2 = new Thread(new ParameterizedThreadStart(readwrite.read_2));
            thread_1.Name = "Первый поток завершен";
            thread_2.Name = "Второй поток завершен";
            thread_1.Start(thread_1.Name);
            thread_2.Start(thread_2.Name);
            Console.ReadKey();
        }
    }
}
